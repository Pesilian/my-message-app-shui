import React from 'react';

const Header = () => {
  return (
    <div>
      <h1 className="header">Shui Messages</h1>
    </div>
  );
};

export default Header;
